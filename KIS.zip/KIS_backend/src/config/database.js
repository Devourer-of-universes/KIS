const { Pool } = require('pg');

const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'corporate_messenger',
    user: process.env.DB_USER || 'messenger_user',
    password: process.env.DB_PASSWORD || 'mes123user',
});

pool.on('connect', () => {
    console.log('✅ Connected to PostgreSQL');
});

pool.on('error', (err) => {
    console.error('❌ Database error:', err);
});

const query = (text, params) => pool.query(text, params);

module.exports = { pool, query };